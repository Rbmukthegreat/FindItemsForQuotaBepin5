# FindItemsForQuota
A mod that finds the items that sum as close as possible to quota (a.k.a "min-maxing") and teleports them in front of where they need to be sold.

## Usage
To use this mod, you need to be at the company, wait for the ship to be landed (which is around 21 seconds after the doors of the ship open), and click the backslash key on your keyboard.

## Installation
- Install [BepInEx](https://thunderstore.io/c/lethal-company/p/BepInEx/BepInExPack/)
- Find the location of your game by clicking on the gear and selecting Manage then browse local files
- Extract the mod to BepInEx/plugins

Or let thunderstore handle it.

## References
A lot of the code for this mod has been inspried by [ShipLoot](https://thunderstore.io/c/lethal-company/p/tinyhoot/ShipLoot/). This project would not have been completed without the help of it's source code.